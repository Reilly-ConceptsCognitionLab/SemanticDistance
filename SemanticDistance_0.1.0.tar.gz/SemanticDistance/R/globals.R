#' @importFrom utils globalVariables
NULL

utils::globalVariables(
  c('word', "word_clean", "is_stopword", "id", "value", ".", ".data", ":=",
    "group", "label", 'is_stopword','row_number', 'id_row_postsplit',
    'talker', 'id_turn', 'id_row_orig', ':=', 'n', 'n_words', 'CosDist', 'word_order',
    'Distance_Type', 'z_CosDist', '.', 'word_type', 'Cos_Dist', 'turn_count', 'row_id'
  ))
