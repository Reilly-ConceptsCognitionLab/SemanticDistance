## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#install.packages("devtools") # to install development version, run this
#devtools::install_github("Reilly-ConceptsCognitionLab/ConversationAlign") #installs from github
library(SemanticDistance)

